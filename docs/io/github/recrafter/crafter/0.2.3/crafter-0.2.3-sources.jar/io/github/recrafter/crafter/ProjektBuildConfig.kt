package io.github.recrafter.crafter

import kotlin.String

public object ProjektBuildConfig {
  public const val PLUGIN_NAME: String = "Crafter"

  public const val PLUGIN_VERSION: String = "0.2.3"

  public const val PLUGIN_DEVELOPER: String = "recrafter"
}
