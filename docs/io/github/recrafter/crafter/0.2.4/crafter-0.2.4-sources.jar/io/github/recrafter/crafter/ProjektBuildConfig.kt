package io.github.recrafter.crafter

import kotlin.String

public object ProjektBuildConfig {
  public const val PLUGIN_NAME: String = "Crafter"

  public const val PLUGIN_VERSION: String = "0.2.4"

  public const val PLUGIN_DEVELOPER: String = "recrafter"
}
